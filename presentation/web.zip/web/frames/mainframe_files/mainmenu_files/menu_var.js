        var NoOffFirstLineMenus=5; //set number of main menu items
        var LowBgColor='#F1F1F1';
        var HighBgColor='#C1C1C1';
        var FontLowColor='black';
        var FontHighColor='blue';
        var BorderColor='#404E7D';
        var BorderWidth=1;
	var BorderBtwnElmnts=1;
        var FontFamily="Verdana,comic sans ms,technical,arial"
        var FontFamily2="comic sans ms,technical,arial"
        var FontSize=8;
	var FontBold=1;
	var FontItalic=0;
	var MenuTextCentered=0;
        var MenuCentered='center';
	var MenuVerticalCentered='top';
	var ChildOverlap=.1;
	var ChildVerticalOverlap=.1;
        var StartTop=105; //set vertical offset
	var StartLeft=0; //set horizontal offset
	var VerCorrect=0;
	var HorCorrect=0;
	var LeftPaddng=3;
	var TopPaddng=2;
	var FirstLineHorizontal=1; //set menu layout (1=horizontal, 0=vertical)
        var MenuFramesVertical=0;
	var DissapearDelay=500;
        var TakeOverBgColor=0;
        var FirstLineFrame='header';
        var SecLineFrame='main';
        var DocTargetFrame='main';
	var WebMasterCheck=0;

//Menux=new Array("text to show","Link",No of sub elements,element height,element width);
//see accompanying "config.htm" file for more information on structure of menus

Menu1=new Array("Home","homepage.html",1,20,120);
        Menu1_1=new Array("Home","homepage.html",0,20,130);

Menu2=new Array("War Games Inc","engine.html",4);
        Menu2_1=new Array("War Games Inc. 1.0","engine.html",0,20,200);
        Menu2_2=new Array("WGI Expansion packs","expansion.html",0,20,150);
        Menu2_3=new Array("WGI Screenshots","screenshots.html",0,20,150);
        Menu2_4=new Array("WGI Requirements","requirements.html",0,20,200);

Menu3=new Array("Register","register.html",1);
        Menu3_1=new Array("Register War Games Inc.","register.html",0,20,200);

Menu4=new Array("About us","about.html",1,20,130);
        Menu4_1=new Array("About us","about.html",0,20,130);

Menu5=new Array("Links","contact.html",3);
        Menu5_1=new Array("Contact Information","contact.html",0,20,140);
        Menu5_2=new Array("Shareware links","sharewarelinks.html",0,20,140);
        Menu5_3=new Array("Other links","links.html",0,20,140);
